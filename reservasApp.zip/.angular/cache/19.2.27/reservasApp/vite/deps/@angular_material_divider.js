import {
  MatDivider,
  MatDividerModule
} from "./chunk-UCWOSUVK.js";
import "./chunk-PCQEEKRW.js";
import "./chunk-BBJACHVY.js";
import "./chunk-5QAZBKCL.js";
import "./chunk-2G2IOVHZ.js";
import "./chunk-27KESBNM.js";
import "./chunk-UHD5O56P.js";
import "./chunk-GVSKDZNY.js";
import "./chunk-EAAUV2ZZ.js";
import "./chunk-ZNCRG6OU.js";
export {
  MatDivider,
  MatDividerModule
};
